# Evaluation plan

## Baselines and metrics
- **Baseline:** keyword-only matching against the same role/skill taxonomy.
- **Primary skill metric:** macro-F1 over annotated skill labels.
- **Role recommendation metric:** Recall@5 over relevant role families.
- **Evidence quality:** percentage of inferred skills judged supported by the cited input phrase.
- **Calibration:** Brier score and reliability plot only after obtaining labeled transition outcomes.

## Dataset procedure
1. Inspect the organizer-provided Indian occupational skills dataset and document schema, license/usage restrictions, and coverage.
2. Build a small annotation guide for informal work descriptions.
3. Have two reviewers annotate a subset if possible; reconcile disagreements.
4. Split by person/source so near-duplicate descriptions do not cross train/test boundaries.
5. Freeze mapping rules before evaluating the held-out set.

## Results table template
| Metric | Keyword baseline | THE UNMAPPED | Target |
|---|---:|---:|---:|
| Macro-F1 | To measure | To measure | ≥ 0.75 |
| Recall@5 | To measure | To measure | ≥ baseline + 15 percentage points |
| Evidence supported | To measure | To measure | Report actual value |
| Brier score | N/A until outcome labels exist | N/A until outcome labels exist | Lower is better |

Do not fill in target values as if they were achieved results. Include sample size, split method, limitations and representative error cases in the final report.
