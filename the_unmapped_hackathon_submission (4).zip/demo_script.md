# 3-minute demo script

**0:00–0:25 — The problem**
“Many people gain real skills outside formal jobs. A person who maintains accounts in a family business may have bookkeeping, record-keeping and reporting skills, but a conventional CV or keyword matcher may not recognize them.”

**0:25–1:10 — Skills Signal Engine**
“Here is Divya's informal experience. I click Analyze my skills. The system maps phrases to structured skills and shows the evidence phrase behind each match. That makes the output reviewable rather than a mysterious score.”

**1:10–1:50 — Transition Recommender**
“I choose Accounts Executive. The dashboard compares the profile against the role requirements, shows overlap and missing skills, and suggests a practical learning pathway. This is a planning aid, not a guarantee of employment.”

**1:50–2:15 — Aggregate Signals**
“The market panel is designed to display wage, growth and automation signals from the organizer-provided datasets. In this prototype, values are explicitly marked as illustrative and must be replaced before evaluation.”

**2:15–2:40 — Responsible AI**
“We do not invent a 12-month success probability. That requires historical outcome labels and calibration testing. Skills are shown with evidence, and the user should be able to review or correct them.”

**2:40–3:00 — Falsifiable claim**
“Our claim is that evidence-grounded extraction can reach macro-F1 of at least 0.75 and improve Recall@5 by at least 15 percentage points over keyword-only matching. We will test this on a held-out annotated set and report actual results, including failures.”
