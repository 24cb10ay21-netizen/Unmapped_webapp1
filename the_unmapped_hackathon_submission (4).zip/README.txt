THE UNMAPPED — Hackathon Submission Package
Track: PS-02 | Social Upliftment

PROBLEM
Informal work, family-business responsibilities, self-learning and community experience often build real skills that formal CVs and keyword-based hiring systems fail to recognize.

SOLUTION
THE UNMAPPED turns free-text experience into an evidence-backed skill profile, compares it with a target role, explains skill gaps, and proposes a practical learning pathway. Market insights are designed to use the organizer-provided labor-market datasets.

RUN THE PROTOTYPE
1. Extract this ZIP.
2. Open index.html in Chrome, Edge, or Firefox.
3. Enter an experience description and click “Analyze my skills”.
4. Change the target role to compare gaps and learning pathways.
5. Export the profile as JSON.

FILES
- index.html: standalone interactive frontend prototype.
- card.md: falsifiable claim, intervention, metrics, control condition, and test protocol.
- submission.md: problem, solution, innovation, impact, feasibility, and limitations.
- demo_script.md: short live-demo script.
- evaluation_plan.md: test plan and reporting template.

IMPORTANT HONESTY NOTE
The current app is a frontend prototype with a small demo taxonomy and illustrative market figures. It does not yet use the organizer datasets and does not claim a calibrated 12-month transition probability. Before final evaluation, replace demo taxonomy/market data with the supplied datasets, test on held-out annotated examples, and report measured results rather than targets.
