# Falsifiable Claim — THE UNMAPPED

## Claim
We claim that, on a held-out set of informal Indian work-experience descriptions, **THE UNMAPPED's evidence-grounded skill extraction pipeline will achieve macro-F1 ≥ 0.75 and improve Recall@5 for relevant occupational skills by at least 15 percentage points over a keyword-only baseline**.

## Intervention
The system normalizes free-text descriptions of informal work, self-learning, family-business responsibilities, and projects; maps phrases to the organizer-provided Indian occupational skills taxonomy; and stores the matched evidence phrases alongside each inferred skill. Role recommendations then compare the evidence-backed skill profile with role-family requirements and explain skill gaps and a suggested learning pathway.

## Measurement
- **Skill extraction:** macro-F1 on a manually annotated, held-out test set.
- **Role retrieval:** Recall@5 for relevant role families, compared with keyword-only matching.
- **Evidence audit:** reviewers check whether each extracted skill is supported by a phrase in the user's description.
- **Transition confidence:** no probability is shown until labeled historical transition outcomes are available and calibration has been evaluated using reliability plots and Brier score.

## Control condition
A keyword-only baseline that matches the same input text against role and skill keywords, without phrase normalization, taxonomy-aware mapping, or evidence display.

## Test protocol
1. Use the organizer-provided Indian skills dataset and build a small, documented annotation set of informal descriptions.
2. Split examples by person/source before testing to reduce leakage.
3. Freeze the taxonomy and thresholds before running the held-out evaluation.
4. Report macro-F1, Recall@5, confidence intervals where feasible, and examples of false positives/false negatives.
5. If either threshold is missed, report the measured result honestly and identify the next improvement.

## Scope and limitation
This is a testable target, not a claimed result. Current frontend demo figures are illustrative. Replace the prototype taxonomy and market figures with the supplied event datasets before making any real-world labor-market or transition-probability claim.
