# THE UNMAPPED
### Career-skill intelligence for India's overlooked talent
**Track:** PS-02 — Social Upliftment

## 1. Problem
Many people develop job-relevant skills outside formal education and conventional employment: helping run a family business, maintaining accounts, supporting customers, managing records, learning tools independently, or coordinating community activities. Their abilities may be real and demonstrable, but standard CVs and keyword-driven recommendation systems often fail to represent them. This creates a visibility gap between what a person can do and what a hiring system can recognize.

## 2. Proposed solution
THE UNMAPPED is a career-skill intelligence prototype that translates informal experience into structured, reviewable evidence. It is designed around three components:

1. **Skills Signal Engine:** accepts free-text descriptions and maps relevant phrases to skills from an Indian occupational taxonomy. Each skill is shown with the phrase that triggered it, so the user can review and correct the interpretation.
2. **Transition Recommender:** compares the user's current skill profile with a selected target role, displays overlap and missing skills, and proposes a staged learning pathway. The prototype avoids presenting an unvalidated probability as fact.
3. **Aggregate Signals Dashboard:** presents wage, role-growth and automation-exposure views using the event-provided datasets. The current frontend contains clearly labeled illustrative values that must be replaced before evaluation.

## 3. Example user journey
Divya, 23, has completed Class 12 and spent two years helping manage accounts for her family's textile business. She learned basic Tally and Python independently and maintained records and reports. Instead of treating her profile as “no experience,” the system identifies evidence-backed skills such as bookkeeping, record keeping, basic Tally, reporting and Python basics. When she selects Accounts Executive, it highlights gaps such as GST fundamentals or advanced Tally and suggests a learning sequence.

The system does not claim that Divya is guaranteed a job. It helps her describe her existing capabilities, identify the next skills to build, and make a more informed transition plan.

## 4. What makes it different
- **Evidence, not just labels:** every inferred skill is linked to the phrase in the user's description that supports it.
- **Indian occupational context:** role families and skill mapping are intended to use the organizer's Indian skills dataset, with O*NET and ESCO as optional crosswalks.
- **Actionable gap analysis:** results include a target role, missing skills and a learning pathway.
- **Responsible confidence:** a 12-month transition probability is withheld until labeled outcomes and calibration testing support it.
- **Transparent limitations:** market values are labeled as illustrative until replaced with sourced event data.

## 5. Technical approach
- Frontend: HTML, CSS and vanilla JavaScript; responsive standalone prototype.
- Skill extraction: phrase matching and taxonomy mapping in the current demo; next iteration adds normalization, phrase variants and semantic matching while retaining evidence spans.
- Role matching: overlap between extracted skills and role-family requirements.
- Export: downloadable JSON profile for reuse by a counselor, placement cell or training partner.
- Evaluation: macro-F1 for skill extraction, Recall@5 for role retrieval, evidence audit, and Brier score/reliability analysis only when labeled transition outcomes exist.

## 6. Feasibility and implementation plan
**Phase 1 — Working prototype:** demonstrate profile input, evidence-backed skills, role selector, gap list, learning pathway, market tabs and JSON export.

**Phase 2 — Dataset integration:** map the organizer's Indian skills dataset into the app taxonomy; document role and skill identifiers; replace all illustrative wage/growth/automation figures with the supplied data and metadata.

**Phase 3 — Evaluation:** annotate a held-out set of informal experience descriptions, compare with keyword-only baseline, report macro-F1 and Recall@5, and inspect false positives/negatives.

**Phase 4 — Responsible pilot:** test with students, informal workers and career counselors; add edit/remove controls for inferred skills, privacy notice, consent, and deletion of profile data.

## 7. Social impact
THE UNMAPPED aims to make nontraditional experience more legible to career services, skilling programs and job seekers. It can support career counseling and targeted training by showing both existing strengths and realistic next steps. It should be used as a decision-support tool, not as an automated hiring filter.

## 8. Risks and safeguards
- **Incorrect skill inference:** display evidence phrases and let users review or remove inferred skills.
- **Dataset bias:** document dataset coverage and evaluate across different descriptions and backgrounds where feasible.
- **Misleading labor-market figures:** only use the organizer datasets for claims; show source and date.
- **False confidence:** do not show a 12-month probability until validated against real outcomes and calibrated.
- **Privacy:** minimize personal data, obtain consent for any pilot, and avoid retaining raw descriptions unnecessarily.

## 9. Success criteria
The falsifiable target in `card.md` is macro-F1 ≥ 0.75 and at least a 15-percentage-point Recall@5 improvement over a keyword-only baseline on a held-out annotated set. These are targets to test, not results already achieved. We will report actual scores and limitations transparently.
